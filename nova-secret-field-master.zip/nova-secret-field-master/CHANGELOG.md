# Changelog

## 1.1.0 - 2020-05-05

- Add copy to clipboard feature

## 1.0.5 - 2020-05-05

- Fix readonly behaviour
- Fix show button style to match Nova's standard
- Add tooltip on show button hover

